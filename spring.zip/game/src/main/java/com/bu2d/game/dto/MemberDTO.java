package com.bu2d.game.dto;

import com.bu2d.game.entity.MemberEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class MemberDTO {
    private Long number;
    private String id;
    private String pw;
    private String name;

    public static MemberDTO toMemberDTO(MemberEntity memberEntity) {
        MemberDTO memberDTO = new MemberDTO();
        memberDTO.setId(memberEntity.getId());
        memberDTO.setPw(memberEntity.getPw());
        memberDTO.setNumber(memberEntity.getNumber());
        memberDTO.setName(memberEntity.getName());
        return memberDTO;
    }
}
