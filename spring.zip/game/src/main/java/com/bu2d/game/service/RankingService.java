package com.bu2d.game.service;
import com.bu2d.game.dto.RankingDTO;
import com.bu2d.game.entity.RankingEntity;
import com.bu2d.game.repository.RankingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class RankingService {

    @Autowired
    private RankingRepository rankingRepository;
    Sort sort = Sort.by(Sort.Direction.ASC, "score");

    public List<RankingDTO> findAll(){
        List<RankingEntity> rankingEntityList = rankingRepository.findAll();
        return rankingEntityList.stream()
                .map(RankingDTO::toRankingDTO)
                .collect(Collectors.toList());
    }

 }
