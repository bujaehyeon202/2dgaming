package com.bu2d.game.entity;

import com.bu2d.game.dto.RankingDTO;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Getter
@Table(name="SCORE")
public class RankingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int a;
    @Column
    private Long number;

    @Column
    private String score;

    @Column
    private String name;

    public static RankingEntity toRankingEntity(RankingDTO rankingDTO){
        RankingEntity RankingEntity = new RankingEntity();
        RankingEntity.setNumber(rankingDTO.getNumber());
        RankingEntity.setScore(rankingDTO.getScore());
        RankingEntity.setName(rankingDTO.getName());
        return RankingEntity;
    }
}
