package com.bu2d.game.dto;

import com.bu2d.game.entity.RankingEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class RankingDTO {
    private Long number;
    private String name;
    private String score;

    public static RankingDTO toRankingDTO(RankingEntity RankingEntity) {
        RankingDTO RankingDTO = new RankingDTO();
        RankingDTO.setName(RankingEntity.getName());
        RankingDTO.setNumber(RankingEntity.getNumber());
        RankingDTO.setScore(RankingEntity.getScore());
        return RankingDTO;
    }
}
