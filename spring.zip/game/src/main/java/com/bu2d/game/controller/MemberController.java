package com.bu2d.game.controller;

import com.bu2d.game.dto.MemberDTO;
import com.bu2d.game.dto.RankingDTO;
import com.bu2d.game.entity.RankingEntity;
import com.bu2d.game.repository.RankingRepository;
import com.bu2d.game.service.MemberService;
import com.bu2d.game.service.RankingService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@Controller
@RequiredArgsConstructor
public class MemberController {
    // 생성자 주입
    private final MemberService memberService;
    private final RankingService rankingService;
    // 회원가입 페이지 출력 요청
    @GetMapping("/game/save")
    public String saveForm() {
        return "save";
    }

    @PostMapping("/game/save")
    public String save(@ModelAttribute MemberDTO memberDTO) {
        System.out.println("MemberController.save");
        System.out.println("memberDTO = " + memberDTO);
        memberService.save(memberDTO);
        return "index";
    }

    @GetMapping("/game/login")
    public String loginForm(){
        return "login";
    }

    @PostMapping("/game/login")
    public String login(@ModelAttribute MemberDTO memberDTO, HttpSession session){
       MemberDTO loginRes = memberService.login(memberDTO);
       if(loginRes !=null){
           session.setAttribute("loginId",loginRes.getId());
           return "main";
       }
       else{
           //실패
           return "login";
       }
    }

    @GetMapping("game/list")
    public String findAll(Model model){
        List<MemberDTO> memberDtoList = memberService.findAll();
        model.addAttribute("memberList",memberDtoList);
        return "list";
    }

    @GetMapping("game/ranking")
    public String findRanking(Model model){
         List<RankingDTO> rankingDtoList = rankingService.findAll();
        model.addAttribute("SCOREList",rankingDtoList);
        return "ranking";
    }
    @GetMapping("game/start")
    public void startGame(){

        Runtime rt = Runtime.getRuntime();
        String exeFile = "C:\\cave\\launcher";
        System.out.println("exeFile: " + exeFile);
        Process p;

        try {
            p = rt.exec(exeFile);
            p.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}