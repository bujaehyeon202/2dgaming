package com.bu2d.game.repository;

import com.bu2d.game.entity.RankingEntity;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface RankingRepository extends JpaRepository<RankingEntity, Long> {
    List<RankingEntity> findAll(Sort sort);
}
