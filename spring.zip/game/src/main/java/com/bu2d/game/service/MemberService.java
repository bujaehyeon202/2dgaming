package com.bu2d.game.service;

import com.bu2d.game.entity.MemberEntity;
import com.bu2d.game.repository.MemberRepository;
import com.bu2d.game.dto.MemberDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.lang.reflect.Member;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class MemberService {
    private final MemberRepository memberRepository;
    public void save(MemberDTO memberDTO) {
        MemberEntity memberEntity = MemberEntity.toMemberEntity(memberDTO);
        memberRepository.save(memberEntity);
    }

    public MemberDTO login(MemberDTO memberDTO){
        /* id pw db에서 조회 > db의 id pw와 입력한 id pw가 일치하는지 판단*/
        Optional<MemberEntity> byMemberId = memberRepository.findById(memberDTO.getId());
        if(byMemberId.isPresent()) {
            MemberEntity memberEntity = byMemberId.get();
            if(memberEntity.getPw().equals(memberDTO.getPw())){
                MemberDTO dto = MemberDTO.toMemberDTO(memberEntity);
                return dto;
            }
            else{
                return null;
            }
        }
        else{
            return null;
        }
    }

    public List<MemberDTO> findAll(){
        List<MemberEntity> memberEntitieList = memberRepository.findAll();
        List<MemberDTO> memberDTOList = new ArrayList<>();
        for(MemberEntity memberEntity: memberEntitieList){
            memberDTOList.add(MemberDTO.toMemberDTO((memberEntity)));
        }
        return memberDTOList;
    }

}
