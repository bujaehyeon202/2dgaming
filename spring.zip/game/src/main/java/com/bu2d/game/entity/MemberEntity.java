package com.bu2d.game.entity;

import com.bu2d.game.dto.MemberDTO;
import com.bu2d.game.repository.MemberRepository;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Getter
@Table(name="member_table")
public class MemberEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long number;

    @Column(unique=true)
    private String id;

    @Column
    private String pw;

    @Column
    private String name;

    public static MemberEntity toMemberEntity(MemberDTO memberDTO){
        MemberEntity memberEntity = new MemberEntity();
        memberEntity.setNumber(memberDTO.getNumber());
        memberEntity.setId(memberDTO.getId());
        memberEntity.setPw(memberDTO.getPw());
        memberEntity.setName(memberDTO.getName());
        return memberEntity;
    }


}
