package kr.ac.toast0304;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //버튼 클래스 사용 객체생성 인스턴스생성 객체참조변수 선언
    Button btn1,btn2,btn3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //화면 시작 수행 메소드 버튼에 동작되어야함
        btn1=(Button) findViewById(R.id.btn1);//객체생성 메모리 할당
        btn1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Push",Toast.LENGTH_LONG).show();//매개변수 앱정보,글자 까만 메세지, 떠있는 시간
            }
        });
        btn2=(Button)findViewById(R.id.btn2);
        btn2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
               Toast.makeText(getApplicationContext(),"20212028 박재현",Toast.LENGTH_LONG).show();
            }
        });
        btn3=(Button) findViewById(R.id.btn3);
        btn3.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Nexus",Toast.LENGTH_LONG).show();
            }
        });
    }
}